#include <GLFW\glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <iostream>
#include <vector>
#include <windows.h>
#include <time.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <GL/glu.h>
#include <GL/gl.h>
#include <GL/freeglut.h>

using namespace std;

#define PI 3.1415927

// camera
const int WINDOW_WIDTH = 800;
const int WINDOW_HEIGHT = 1000;
//The camera class will handle all movement in the program.
class Camera {
public:
	glm::vec3 position;
	glm::vec3 direction;
	glm::vec3 up;

	float yaw;
	float pitch;

	float movementSpeed;
	float rotationSpeed;

	Camera(glm::vec3 position = glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3 direction = glm::vec3(0.0f, 0.0f, -1.0f), glm::vec3 up = glm::vec3(0.0f, 1.0f, 0.0f)) {
		this->position = position;
		this->direction = direction;
		this->up = up;

		yaw = -90.0f;
		pitch = 0.0f;

		movementSpeed = 5.0f;
		rotationSpeed = 5.0f;
	}

	void moveForward(float distance) {
		position += direction * distance;
	}

	void moveBackward(float distance) {
		position -= direction * distance;
	}

	void moveLeft(float distance) {
		glm::vec3 left = glm::cross(up, direction);
		position += left * distance;
	}

	void moveRight(float distance) {
		glm::vec3 left = glm::cross(up, direction);
		position -= left * distance;
	}

	void moveUp(float distance) {
		position += up * distance;
	}

	void moveDown(float distance) {
		position -= up * distance;
	}

	void rotate(float yawOffset, float pitchOffset) {
		yaw += yawOffset;
		pitch += pitchOffset;

		glm::vec3 directionVector;
		directionVector.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
		directionVector.y = sin(glm::radians(pitch));
		directionVector.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));

		direction = glm::normalize(directionVector);
	}

	glm::mat4 getViewMatrix() {
		return glm::lookAt(position, position + direction, up);
	}
};
//The quads class will handle anything that has to do with gl_quads. From the table to the walls to the scoreboard.
class Quads
{
public:
	void drawTable()
	{

		glColor3f(0.5f, 0.5f, 0.5f); // Set the color to gray
		// Table
		glBegin(GL_QUADS);
		

		// Front face
		glVertex3f(-0.75f, 0.525f, 1.25f);
		glVertex3f(0.75f, 0.525f, 1.25f);
		glVertex3f(0.75f, 0.125f, 1.25f);
		glVertex3f(-0.75f, 0.125f, 1.25f);

		// Back face
		glVertex3f(-0.75f, 0.125f, -1.25f);
		glVertex3f(0.75f, 0.125f, -1.25f);
		glVertex3f(0.75f, 0.525f, -1.25f);
		glVertex3f(-0.75f, 0.525f, -1.25f);

		// Left face
		glVertex3f(-0.75f, 0.125f, 1.25f);
		glVertex3f(-0.75f, 0.125f, -1.25f);
		glVertex3f(-0.75f, 0.525f, -1.25f);
		glVertex3f(-0.75f, 0.525f, 1.25f);

		// Right face
		glVertex3f(0.75f, 0.125f, 1.25f);
		glVertex3f(0.75f, 0.125f, -1.25f);
		glVertex3f(0.75f, 0.525f, -1.25f);
		glVertex3f(0.75f, 0.525f, 1.25f);

		// Bottom face
		glVertex3f(-0.75f, 0.125f, 1.25f);
		glVertex3f(0.75f, 0.145f, 1.25f);
		glVertex3f(0.75f, 0.125f, -1.25f);
		glVertex3f(-0.75f, 0.145f, -1.25f);

		// Legs

		// Left leg

		glVertex3f(-0.75f, 0.0f, 1.25f);
		glVertex3f(-0.75f, 0.0f, -1.25f);
		glVertex3f(-0.75f, 0.525f, -1.25f);
		glVertex3f(-0.75f, 0.525f, 1.25f);

		glVertex3f(-0.625f, 0.0f, 1.25f);
		glVertex3f(-0.625f, 0.0f, -1.25f);
		glVertex3f(-0.625f, 0.505f, -1.25f);
		glVertex3f(-0.625f, 0.505f, 1.25f);
		// Bottom
		glVertex3f(-0.75f, 0.0f, 1.25f);
		glVertex3f(-0.75f, 0.02f, -1.25f);
		glVertex3f(-0.625f, 0.02f, -1.25f);
		glVertex3f(-0.625f, 0.0f, 1.25f);

		// middle
		glVertex3f(-0.75f, 0.2625f, 1.25f);
		glVertex3f(-0.75f, 0.2425f, -1.25f);
		glVertex3f(-0.625f, 0.2425f, -1.25f);
		glVertex3f(-0.625f, 0.2625f, 1.25f); 

		// middle
		glVertex3f(-0.75f, 0.13125f, 1.25f);
		glVertex3f(-0.75f, 0.11125f, -1.25f);
		glVertex3f(-0.625f, 0.11125f, -1.25f);
		glVertex3f(-0.625f, 0.13125f, 1.25f);

		// top
		glVertex3f(-0.75f, 0.39375f, 1.25f);
		glVertex3f(-0.75f, 0.37375f, -1.25f);
		glVertex3f(-0.625f, 0.37375f, -1.25f);
		glVertex3f(-0.625f, 0.39375f, 1.25f);



		
		// Right leg

		glVertex3f(0.75f, 0.0f, 1.25f);
		glVertex3f(0.75f, 0.0f, -1.25f);
		glVertex3f(0.75f, 0.525f, -1.25f);
		glVertex3f(0.75f, 0.525f, 1.25f);

		glVertex3f(0.625f, 0.0f, 1.25f);
		glVertex3f(0.625f, 0.0f, -1.25f);
		glVertex3f(0.625f, 0.525f, -1.25f);
		glVertex3f(0.625f, 0.525f, 1.25f);

		// Right leg faces
		// Bottom
		glVertex3f(0.75f, 0.0f, 1.25f);
		glVertex3f(0.75f, 0.02f, -1.25f);
		glVertex3f(0.625f, 0.02f, -1.25f);
		glVertex3f(0.625f, 0.0f, 1.25f);

		// middle
		glVertex3f(0.75f, 0.2625f, 1.25f);
		glVertex3f(0.75f, 0.2425f, -1.25f);
		glVertex3f(0.625f, 0.2425f, -1.25f);
		glVertex3f(0.625f, 0.2625f, 1.25f);

		// middle
		glVertex3f(0.75f, 0.13125f, 1.25f);
		glVertex3f(0.75f, 0.11125f, -1.25f);
		glVertex3f(0.625f, 0.11125f, -1.25f);
		glVertex3f(0.625f, 0.13125f, 1.25f);

		// top
		glVertex3f(0.75f, 0.39375f, 1.25f);
		glVertex3f(0.75f, 0.37375f, -1.25f);
		glVertex3f(0.625f, 0.37375f, -1.25f);
		glVertex3f(0.625f, 0.39375f, 1.25f);

		glEnd();

		glColor3f(1.0f, 1.0f, 1.0f);
		glBegin(GL_QUADS);
		// Top face
		glVertex3f(-0.75f, 0.525f, 1.25f);
		glVertex3f(0.75f, 0.525f, 1.25f);
		glVertex3f(0.75f, 0.505f, -1.25f);
		glVertex3f(-0.75f, 0.505f, -1.25f);
		glEnd();
	}
	void drawWalls() {
		glColor3f(0.0f, 0.0f, 0.8f); // Set the color to blue
		glBegin(GL_QUADS);

		// Translate the camera position to the center of the scene
		glTranslatef(0.0f, 0.0f, -5.0f);

		// Side 1 (left)
		glVertex3f(-2.0f, 0.0f, 0.0f);
		glVertex3f(-2.0f, 0.0f, 2.0f);
		glVertex3f(-2.0f, 2.0f, 2.0f);
		glVertex3f(-2.0f, 2.0f, 0.0f);

		// Side 2 (right)
		glVertex3f(2.0f, 0.0f, 0.0f);
		glVertex3f(2.0f, 0.0f, 2.0f);
		glVertex3f(2.0f, 2.0f, 2.0f);
		glVertex3f(2.0f, 2.0f, 0.0f);

		// Side 3 (front)
		glVertex3f(-2.0f, 0.0f, 2.0f);
		glVertex3f(2.0f, 0.0f, 2.0f);
		glVertex3f(2.0f, 2.0f, 2.0f);
		glVertex3f(-2.0f, 2.0f, 2.0f);

		// Side 4 (back)
		glVertex3f(-2.0f, 0.0f, 0.0f);
		glVertex3f(2.0f, 0.0f, 0.0f);
		glVertex3f(2.0f, 2.0f, 0.0f);
		glVertex3f(-2.0f, 2.0f, 0.0f);

		glEnd();
	}
	void drawScoreboard() {
		glPushMatrix();
		glTranslatef(0.0f, 0.0f, 0.0f); // Move the scoreboard to the back of the table
		glScalef(0.25f, 0.25f, 0.25f);   // Scale the scoreboard to fit on top of the table

		glColor3f(1.0f, 1.0f, 1.0f); // Set the color to white
		glBegin(GL_QUADS);

		// TOP
		glVertex3f(4.0f, 3.0f, -1.0f);
		glVertex3f(3.0f, 3.0f, -1.0f);
		glVertex3f(3.0f, 3.0f, 1.0f);
		glVertex3f(4.0f, 3.0f, 1.0f);

		// BOTTOM
		glVertex3f(4.0f, 2.0f, -5.0f);
		glVertex3f(3.0f, 2.0f, -5.0f);
		glVertex3f(3.0f, 2.0f, 5.0f);
		glVertex3f(4.0f, 2.0f, 5.0f);

		// RIGHT
		glVertex3f(4.0f, 2.0f, 1.0f);
		glVertex3f(3.0f, 2.0f, 1.0f);
		glVertex3f(3.0f, 3.0f, 1.0f);
		glVertex3f(4.0f, 3.0f, 1.0f);

		// LEFT
		glVertex3f(4.0f, 2.0f, -1.0f);
		glVertex3f(3.0f, 2.0f, -1.0f);
		glVertex3f(3.0f, 3.0f, -1.0f);
		glVertex3f(4.0f, 3.0f, -1.0f);

		// BACK
		glVertex3f(4.0f, 2.0f, -1.0f);
		glVertex3f(4.0f, 3.0f, -1.0f);
		glVertex3f(4.0f, 3.0f, 1.0f);
		glVertex3f(4.0f, 2.0f, 1.0f);

		// SCREEN
		glColor3ub(90, 76, 76);
		glVertex3f(3.0f, 2.2f, -0.8f);
		glVertex3f(3.0f, 2.8f, -0.8f);
		glVertex3f(3.0f, 2.8f, 0.8f);
		glVertex3f(3.0f, 2.2f, 0.8f);

		glEnd();
		glPopMatrix();
	}
};
//This class is for the strikers and pucks
class StrikerAndPucks {
public:
	void draw_cylinder1(GLfloat radius, GLfloat height, GLubyte R, GLubyte G, GLubyte B)
	{
		GLfloat x = 0.0;
		GLfloat y = 0.0;
		GLfloat angle = 0.0;
		GLfloat angle_stepsize = 0.1;

		/** Draw the tube */
		glColor3f(R / 255.0f, G / 255.0f, B / 255.0f);
		glBegin(GL_QUAD_STRIP);
		angle = 0.0;
		while (angle < 2 * PI) {
			x = radius * cos(angle);
			y = radius * sin(angle);
			glVertex3f(x, y, height);
			glVertex3f(x, y, 0.0);
			angle = angle + angle_stepsize;
		}
		glVertex3f(radius, 0.0, height);
		glVertex3f(radius, 0.0, 0.0);
		glEnd();

		/** Draw the circle on top of cylinder */
		glColor3ub(R, G, B);
		glBegin(GL_POLYGON);
		angle = 0.0;
		while (angle < 2 * PI) {
			x = radius * cos(angle);
			y = radius * sin(angle);
			glVertex3f(x, y, height);
			angle = angle + angle_stepsize;
		}
		glVertex3f(radius, 0.0, height);
		glEnd();
	}

	void draw_cylinder2(GLfloat radius, GLfloat height, GLubyte R, GLubyte G, GLubyte B)
	{
		GLfloat x = 0.0;
		GLfloat y = 0.0;
		GLfloat angle = 0.0;
		GLfloat angle_stepsize = 0.1;

		/** Draw the tube */
		glColor3f(R / 255.0f, G / 255.0f, B / 255.0f);
		glBegin(GL_QUAD_STRIP);
		angle = 0.0;
		while (angle < 2 * PI) {
			x = radius * cos(angle);
			y = radius * sin(angle);
			glVertex3f(x, y, height);
			glVertex3f(x, y, 0.0);
			angle = angle + angle_stepsize;
		}
		glVertex3f(radius, 0.0, height);
		glVertex3f(radius, 0.0, 0.0);
		glEnd();
	}

};


int main(int argc, char** argv) {
	glfwInit();
	glutInit(&argc, argv);

	if (!glfwInit()) {
		exit(EXIT_FAILURE);
	}
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 2);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
	GLFWwindow* window = glfwCreateWindow(WINDOW_HEIGHT, WINDOW_WIDTH, "Air Hockey Table", NULL, NULL);

	if (!window) {
		glfwTerminate();
		exit(EXIT_FAILURE);
	}
	glfwMakeContextCurrent(window);
	glfwSwapInterval(1);

	Camera camera;
	Quads table, walls;
	StrikerAndPucks snp1, snp2, snp3;

	double lastMouseX, lastMouseY;
	glfwGetCursorPos(window, &lastMouseX, &lastMouseY);

	while (!glfwWindowShouldClose(window)) {
		//Setup View
		float ratio;
		int width, height;
		glfwGetFramebufferSize(window, &width, &height);
		ratio = width / (float)height;
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		gluPerspective(0.0f, ratio, 0.1f, 100.0f);

		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		glViewport(0, 0, width, height);
		glm::mat4 viewMatrix = camera.getViewMatrix();
		glMultMatrixf(glm::value_ptr(viewMatrix));

		// Handle keyboard input
		if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS) {
			glfwSetWindowShouldClose(window, true);
		}
		if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {
			camera.moveForward(camera.movementSpeed * 0.01f);
		}
		if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) {
			camera.moveBackward(camera.movementSpeed * 0.01f);
		}
		if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {
			camera.moveLeft(camera.movementSpeed * 0.01f);
		}
		if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {
			camera.moveRight(camera.movementSpeed * 0.01f);
		}
		if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) {
			camera.moveUp(camera.movementSpeed * 0.01f);
		}
		if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) {
			camera.moveDown(camera.movementSpeed * 0.01f);
		}

		// Handle mouse input
		double mouseX, mouseY;
		glfwGetCursorPos(window, &mouseX, &mouseY);
		float deltaX = mouseX - lastMouseX;
		float deltaY = mouseY - lastMouseY;
		lastMouseX = mouseX;
		lastMouseY = mouseY;

		camera.rotate(deltaX * camera.rotationSpeed * 0.01f, deltaY * camera.rotationSpeed * 0.01f);

// Draws the schen here
		glBegin(GL_QUADS);
		glVertex3f(10.0f, 0.0f, 10.0f);
		glVertex3f(-10.0f, 0.0f, 10.0f);
		glVertex3f(-10.0f, 0.0f, -10.0f);
		glVertex3f(10.0f, 0.0f, -10.0f);
		glEnd();
		
		walls.drawWalls();
		table.drawTable();
		table.drawScoreboard();
		glRotatef(-90.0, 1.0, 0.0, 0.00);
		glTranslatef(0.0, 0.0, 0.520);
		snp1.draw_cylinder1(0.032, 0.020, 255, 150, 100);
		snp1.draw_cylinder1(0.032, 0.020, 255, 150, 100);
		snp1.draw_cylinder2(0.032, 0.034, 255, 150, 100);
		glTranslatef(0.15, 0.0, 0.0);
		snp2.draw_cylinder1(0.032, 0.020, 255, 150, 100);
		snp2.draw_cylinder1(0.032, 0.020, 255, 150, 100);
		snp2.draw_cylinder2(0.032, 0.034, 255, 150, 100);
		//puck
		glTranslatef(0.10, 0.0, 0.0);
		snp3.draw_cylinder2(.032, 0.010, 255, 150, 100);
		snp3.draw_cylinder1(0.032, 0.014, 2, 17, 122);




		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	glfwDestroyWindow(window);
	glfwTerminate();
	exit(EXIT_SUCCESS);
}