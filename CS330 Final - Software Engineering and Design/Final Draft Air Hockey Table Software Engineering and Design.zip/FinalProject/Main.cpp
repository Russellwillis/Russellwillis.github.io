#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <GL/freeglut.h>


using namespace std;

#define PI 3.1415927

// camera
const int WINDOW_WIDTH = 800;
const int WINDOW_HEIGHT = 600;

// The camera class will handle all movement in the program.
class Camera {
public:
    glm::vec3 position;
    glm::vec3 direction;
    glm::vec3 up;

    float yaw;
    float pitch;

    float movementSpeed;
    float rotationSpeed;

    Camera(glm::vec3 position = glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3 direction = glm::vec3(0.0f, 0.0f, -1.0f), glm::vec3 up = glm::vec3(0.0f, 1.0f, 0.0f)) {
        this->position = position;
        this->direction = direction;
        this->up = up;

        yaw = -90.0f;
        pitch = 0.0f;

        movementSpeed = 5.0f;
        rotationSpeed = 5.0f;
    }

    void moveForward(float distance) {
        position += direction * distance;
    }

    void moveBackward(float distance) {
        position -= direction * distance;
    }

    void moveLeft(float distance) {
        glm::vec3 left = glm::cross(up, direction);
        position += left * distance;
    }

    void moveRight(float distance) {
        glm::vec3 left = glm::cross(up, direction);
        position -= left * distance;
    }

    void moveUp(float distance) {
        position += up * distance;
    }

    void moveDown(float distance) {
        position -= up * distance;
    }

    void rotate(float yawOffset, float pitchOffset) {
        yaw += yawOffset;
        pitch += pitchOffset;

        glm::vec3 directionVector;
        directionVector.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
        directionVector.y = sin(glm::radians(pitch));
        directionVector.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));

        direction = glm::normalize(directionVector);
    }

    glm::mat4 getViewMatrix() {
        return glm::lookAt(position, position + direction, up);
    }
};

// The quads class will handle anything that has to do with GL_QUADS.
class Quads {
public:
    void drawTable() {
        glColor3f(1.0f, 1.0f, 1.0f); // Table color
        glBegin(GL_QUADS);

        // Table top surface
        glVertex3f(-2.0f, 0.525f, 1.0f);
        glVertex3f(2.0f, 0.525f, 1.0f);
        glVertex3f(2.0f, 0.525f, -1.0f);
        glVertex3f(-2.0f, 0.525f, -1.0f);

        // Table edges
        glColor3f(0.0f, 0.0f, 0.0f); // Edge color

        // Front edge
        glVertex3f(-2.0f, 0.525f, 1.0f);
        glVertex3f(2.0f, 0.525f, 1.0f);
        glVertex3f(2.0f, 0.625f, 1.0f);
        glVertex3f(-2.0f, 0.625f, 1.0f);

        // Back edge
        glVertex3f(-2.0f, 0.525f, -1.0f);
        glVertex3f(2.0f, 0.525f, -1.0f);
        glVertex3f(2.0f, 0.625f, -1.0f);
        glVertex3f(-2.0f, 0.625f, -1.0f);

        // Left edge
        glVertex3f(-2.0f, 0.525f, 1.0f);
        glVertex3f(-2.0f, 0.525f, -1.0f);
        glVertex3f(-2.0f, 0.625f, -1.0f);
        glVertex3f(-2.0f, 0.625f, 1.0f);

        // Right edge
        glVertex3f(2.0f, 0.525f, 1.0f);
        glVertex3f(2.0f, 0.525f, -1.0f);
        glVertex3f(2.0f, 0.625f, -1.0f);
        glVertex3f(2.0f, 0.625f, 1.0f);

        glEnd();

        // Draw table legs
        glColor3f(0.0f, 0.0f, 0.0f); // Color for the legs
        glBegin(GL_QUADS);

        // Front-left leg
        glVertex3f(-1.9f, 0.0f, 0.9f);
        glVertex3f(-1.7f, 0.0f, 0.9f);
        glVertex3f(-1.7f, 0.525f, 0.9f);
        glVertex3f(-1.9f, 0.525f, 0.9f);

        // Front-right leg
        glVertex3f(1.9f, 0.0f, 0.9f);
        glVertex3f(1.7f, 0.0f, 0.9f);
        glVertex3f(1.7f, 0.525f, 0.9f);
        glVertex3f(1.9f, 0.525f, 0.9f);

        // Back-left leg
        glVertex3f(-1.9f, 0.0f, -0.9f);
        glVertex3f(-1.7f, 0.0f, -0.9f);
        glVertex3f(-1.7f, 0.525f, -0.9f);
        glVertex3f(-1.9f, 0.525f, -0.9f);

        // Back-right leg
        glVertex3f(1.9f, 0.0f, -0.9f);
        glVertex3f(1.7f, 0.0f, -0.9f);
        glVertex3f(1.7f, 0.525f, -0.9f);
        glVertex3f(1.9f, 0.525f, -0.9f);


        // Draw goals
        glColor3f(1.0f, 1.0f, 1.0f); // Goal color
        glBegin(GL_QUADS);

        // Left goal
        glVertex3f(-2.1f, 0.525f, 0.2f);
        glVertex3f(-2.1f, 0.525f, -0.2f);
        glVertex3f(-2.0f, 0.525f, -0.2f);
        glVertex3f(-2.0f, 0.525f, 0.2f);

        // Right goal
        glVertex3f(2.1f, 0.525f, 0.2f);
        glVertex3f(2.1f, 0.525f, -0.2f);
        glVertex3f(2.0f, 0.525f, -0.2f);
        glVertex3f(2.0f, 0.525f, 0.2f);

        glEnd();

        // Draw pucks and strikers
        drawPuck(0.0f, 0.525f, 0.0f); // Center puck
        drawStriker(0.5f, 0.525f, 0.0f); // striker
        drawStriker(-0.5f, 0.525f, 0.0f); // striker
    }

    void drawPuck(float x, float y, float z) {
        glColor3f(1.0f, 0.0f, 0.0f); // Red color for the puck
        glBegin(GL_QUADS);

        // Draw a puck as a disk
        float radius = 0.1f;
        int numSegments = 36;
        for (int i = 0; i < numSegments; ++i) {
            float angle1 = 2 * PI * i / numSegments;
            float angle2 = 2 * PI * (i + 1) / numSegments;
            glVertex3f(x + radius * cos(angle1), y, z + radius * sin(angle1));
            glVertex3f(x + radius * cos(angle2), y, z + radius * sin(angle2));
            glVertex3f(x + radius * cos(angle2), y + 0.05f, z + radius * sin(angle2));
            glVertex3f(x + radius * cos(angle1), y + 0.05f, z + radius * sin(angle1));
        }

        glEnd();
    }

    void drawStriker(float x, float y, float z) {
        glColor3f(0.0f, 0.0f, 1.0f); // Blue color for the striker
        glBegin(GL_QUADS);

        // Draw a striker
        float radius = 0.15f;
        int numSegments = 36;
        for (int i = 0; i < numSegments; ++i) {
            float angle1 = 2 * PI * i / numSegments;
            float angle2 = 2 * PI * (i + 1) / numSegments;
            glVertex3f(x + radius * cos(angle1), y, z + radius * sin(angle1));
            glVertex3f(x + radius * cos(angle2), y, z + radius * sin(angle2));
            glVertex3f(x + radius * cos(angle2), y + 0.1f, z + radius * sin(angle2));
            glVertex3f(x + radius * cos(angle1), y + 0.1f, z + radius * sin(angle1));
        }

        glEnd();
    }


    void drawWalls() {
        glColor3f(0.3f, 0.0f, 0.0f); // Set the color to red for walls
        glBegin(GL_QUADS);

        // Front wall
        glVertex3f(-5.0f, 0.0f, 5.0f);
        glVertex3f(5.0f, 0.0f, 5.0f);
        glVertex3f(5.0f, 5.0f, 5.0f);
        glVertex3f(-5.0f, 5.0f, 5.0f);

        // Back wall
        glVertex3f(-5.0f, 0.0f, -5.0f);
        glVertex3f(5.0f, 0.0f, -5.0f);
        glVertex3f(5.0f, 5.0f, -5.0f);
        glVertex3f(-5.0f, 5.0f, -5.0f);

        // Left wall
        glVertex3f(-5.0f, 0.0f, -5.0f);
        glVertex3f(-5.0f, 0.0f, 5.0f);
        glVertex3f(-5.0f, 5.0f, 5.0f);
        glVertex3f(-5.0f, 5.0f, -5.0f);

        // Right wall
        glVertex3f(5.0f, 0.0f, -5.0f);
        glVertex3f(5.0f, 0.0f, 5.0f);
        glVertex3f(5.0f, 5.0f, 5.0f);
        glVertex3f(5.0f, 5.0f, -5.0f);

        glEnd();
    }

    void drawFloor() {
        glColor3f(0.3f, 0.3f, 0.3f); // Light color for the floor
        glBegin(GL_QUADS);

        // Floor
        glVertex3f(-5.0f, -0.01f, -5.0f);
        glVertex3f(5.0f, -0.01f, -5.0f);
        glVertex3f(5.0f, -0.01f, 5.0f);
        glVertex3f(-5.0f, -0.01f, 5.0f);

        glEnd();
    }

    void drawCeiling() {
        glColor3f(0.8f, 0.8f, 0.8f); // Light color for the ceiling
        glBegin(GL_QUADS);

        // Ceiling
        glVertex3f(-5.0f, 5.01f, -5.0f);
        glVertex3f(5.0f, 5.01f, -5.0f);
        glVertex3f(5.0f, 5.01f, 5.0f);
        glVertex3f(-5.0f, 5.01f, 5.0f);

        glEnd();
    }


    void drawScoreboard() {
        glColor3f(0.0f, 0.0f, 0.3f); // Set the color for the scoreboard
        glBegin(GL_QUADS);

        // Scoreboard on the edge of the table, standing up
        // Front face
        glVertex3f(-0.50f, 0.625f, -1.0f);
        glVertex3f(-0.50f, 0.825f, -1.0f);
        glVertex3f(-0.50f, 0.825f, -1.0f);
        glVertex3f(-0.50f, 0.625f, -1.0f);

        // Back face
        glVertex3f(0.5f, 0.625f, -1.0f);
        glVertex3f(0.5f, 0.825f, -1.0f);
        glVertex3f(0.5f, 0.825f, -1.0f);
        glVertex3f(0.5f, 0.625f, -1.0f);

        // Left face
        glVertex3f(-0.50f, 0.625f, -1.0f);
        glVertex3f(0.5f, 0.625f, -1.0f);
        glVertex3f(0.5f, 0.825f, -1.0f);
        glVertex3f(-0.50f, 0.825f, -1.0f);

        // Right face
        glVertex3f(-0.50f, 0.625f, -1.0f);
        glVertex3f(0.5f, 0.625f, -1.0f);
        glVertex3f(0.5f, 0.825f, -1.0f);
        glVertex3f(-0.50f, 0.825f, -1.0f);

        // Top face
        glVertex3f(-0.50f, 0.825f, -1.0f);
        glVertex3f(0.5f, 0.825f, -1.0f);
        glVertex3f(0.5f, 0.825f, -1.0f);
        glVertex3f(-0.50f, 0.825f, -1.0f);

        // Bottom face
        glVertex3f(-0.50f, 0.625f, -1.0f);
        glVertex3f(0.5f, 0.625f, -1.0f);
        glVertex3f(0.5f, 0.625f, -1.0f);
        glVertex3f(-0.50f, 0.625f, -1.0f);

        glEnd();
    }
};

//Key input for movement
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods) {
    if (action == GLFW_PRESS || action == GLFW_REPEAT) {
        Camera* cam = static_cast<Camera*>(glfwGetWindowUserPointer(window));
        switch (key) {
        case GLFW_KEY_W:
            cam->moveForward(0.1f);
            break;
        case GLFW_KEY_S:
            cam->moveBackward(0.1f);
            break;
        case GLFW_KEY_A:
            cam->moveLeft(0.1f);
            break;
        case GLFW_KEY_D:
            cam->moveRight(0.1f);
            break;
        case GLFW_KEY_LEFT:
            cam->rotate(-1.0f, 0.0f);
            break;
        case GLFW_KEY_RIGHT:
            cam->rotate(1.0f, 0.0f);
            break;
        case GLFW_KEY_UP:
            cam->rotate(.0f, 1.0f);
            break;
        case GLFW_KEY_DOWN:
            cam->rotate(0.0f, -1.0f);
            break;
        case GLFW_KEY_Q:
            cam->moveUp(0.1f);
            break;
        case GLFW_KEY_E:
            cam->moveDown(0.1f);
            break;
        }
    }
}

void framebuffer_size_callback(GLFWwindow* window, int width, int height) {
    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0, (double)width / (double)height, 0.1, 100.0);
    glMatrixMode(GL_MODELVIEW);
}

int main(void) {
    GLFWwindow* window;

    // Initialize the library
    if (!glfwInit()) {
        return -1;
    }

    // Create a windowed mode window and its OpenGL context
    window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, "Willis Capstone", NULL, NULL);
    if (!window) {
        glfwTerminate();
        return -1;
    }

    // Make the window's context current
    glfwMakeContextCurrent(window);

    // Set callback functions
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

    // Set up camera
    Camera camera(glm::vec3(0.0f, 1.0f, 5.0f));
    glfwSetWindowUserPointer(window, &camera);

    // Set key callback
    glfwSetKeyCallback(window, key_callback);

    // Initialize GLEW (optional, depending on system)
    GLenum err = glewInit();
    if (err != GLEW_OK) {
        fprintf(stderr, "Error: %s\n", glewGetErrorString(err));
        return -1;
    }

    // Enable depth test
    glEnable(GL_DEPTH_TEST);

    Quads quads;

    // Loop until the user closes the window
    while (!glfwWindowShouldClose(window)) {
        // Render here
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // Set the view matrix based on camera
        glm::mat4 view = camera.getViewMatrix();
        glLoadMatrixf(glm::value_ptr(view));

        // Render a table
        quads.drawTable();
        quads.drawWalls();
        quads.drawScoreboard();
        quads.drawFloor();
        quads.drawCeiling();

        // Swap front and back buffers
        glfwSwapBuffers(window);

        // Poll for and process events
        glfwPollEvents();
    }

    glfwTerminate();
    return 0;
}